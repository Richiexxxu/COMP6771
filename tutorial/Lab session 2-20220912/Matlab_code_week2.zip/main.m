%% Read Images
grayI = imread('lena512.bmp');
colorI = imread('lena512color.tiff');

%% Display Images
imshow(grayI);
title('Grayscale Image');   % display title in the image

figure('Name', 'Display Color Image');                     % Create a new figure window
imshow(colorI);
title('Color Image');

%% Operations on images
% Convert color to grayscale
gray_colorI = rgb2gray(colorI);

% Convert to BW
bw_grayI = im2bw(grayI);

% Negative
neg_grayI = 255 - grayI;

% Extract color channels
[R, G, B] = ExtractColorChannels(colorI);

%% Display result images
figure('Name', 'Result images');

% first image
subplot(1, 3, 1);               % set image position
subimage(grayI);                % plot image
title('Grayscale image');       % set title
axis off;                       % remove axis

% second image
subplot(1, 3, 2);
subimage(bw_grayI);
title('BW image');
axis off;

% third image
subplot(1, 3, 3);
subimage(neg_grayI);
title('Negative image');
axis off;

figure('Name', 'Result images');
% first image
subplot(1, 4, 1);               % set image position
subimage(colorI);                % plot image
title('Color image');       % set title
axis off;                       % remove axis

% second image
subplot(1, 4, 2);
subimage(R);
title('Red channel');
axis off;

% third image
subplot(1, 4, 3);
subimage(G);
title('Green channel');
axis off;

% forth image
subplot(1, 4, 4);
subimage(B);
title('Blue channel');
axis off;