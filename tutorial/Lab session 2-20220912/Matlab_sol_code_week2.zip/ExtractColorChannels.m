function [R, G, B] = ExtractColorChannels(colorI)
    
    R = colorI(:, :, 1);
    B = colorI(:, :, 2);
    G = colorI(:, :, 3);
    
    a = zeros(size(colorI, 1), size(colorI, 2));
    R = cat(3, R, a, a);
    G = cat(3, a, G, a);
    B = cat(3, a, a, B);
end