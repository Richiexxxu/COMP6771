function subI = ExtractSubImage(I, siz, pos)

    M = siz(1); N = siz(2);
    x = pos(1); y = pos(2);
    
    halfM = floor(M/2);
    halfN = floor(N/2);
    
    subI = I(x - halfM + 1:x + halfM, y - halfN + 1:y + halfN);

end