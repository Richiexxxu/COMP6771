function J = flipH(I)

    ncolumns = size(I, 2);
    for c = 1:floor(ncolumns / 2)
        C = I(:, c);
        I(:, c) = I(:, ncolumns - c + 1);
        I(:, ncolumns - c + 1) = C;
    end
    J = I;
end