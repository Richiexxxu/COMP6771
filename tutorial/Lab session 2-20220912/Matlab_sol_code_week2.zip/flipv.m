function J = flipV(I)

    nrows = size(I,1);
    for r = 1:floor(nrows / 2)
        R = I(r, :);
        I(r, :) = I(nrows - r + 1, :);
        I(nrows - r + 1, :) = R;
    end
    J = I;
end