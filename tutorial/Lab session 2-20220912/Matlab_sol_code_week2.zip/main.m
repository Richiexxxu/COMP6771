%% Read Images
grayI = imread('lena512.bmp');
colorI = imread('lena512color.tiff');

%% Display Images
imshow(grayI);
title('Grayscale Image');   % display title in the image

figure('Name', 'Display Color Image');                     % Create a new figure window
imshow(colorI);
title('Color Image');

%% Operations on images
% Convert color to grayscale
gray_colorI = rgb2gray(colorI);

% Convert to BW
bw_grayI = im2bw(grayI);

% Negative
neg_grayI = 255 - grayI;

% Extract color channels
[R, G, B] = ExtractColorChannels(colorI);

% Extract subimage
M = 100;
N = 100;
x = 160;
y = 160;
siz = [M N];
pos = [x y];
subImage = ExtractSubImage(grayI, siz, pos);

% Flip image vertically
v_grayI = flipV(grayI);
v_colorI = flipV(colorI);

% Flip image horizontally
h_grayI = flipH(grayI);
h_colorI = flipH(colorI);

% Rotate image 90 left
l90_grayI = rotate90(grayI, 'left');    % only work for grayscale image

% Rotate image 90 right
r90_grayI = rotate90(grayI, 'right');   % only work for grayscale image

%% Display result images
figure('Name', 'Result grayscale images');

% first image
subplot(2, 4, 1);               % set image position
subimage(grayI);                % plot image
title('Grayscale image');       % set title
axis off;                       % remove axis

% second image
subplot(2, 4, 2);
subimage(bw_grayI);
title('BW image');
axis off;

% third image
subplot(2, 4, 3);
subimage(neg_grayI);
title('Negative image');
axis off;

% forth image
subplot(2, 4, 4);
subimage(subImage);
title('Sub image');
axis off;

% fifth image
subplot(2, 4, 5);
subimage(v_grayI);
title('Vertical flipped image');
axis off;

% sixth image
subplot(2, 4, 6);
subimage(h_grayI);
title('Horizontal flipped image');
axis off;

% seventh image
subplot(2, 4, 7);
subimage(l90_grayI);
title('Rotate 90 left image');
axis off;

% eigth image
subplot(2, 4, 8);
subimage(r90_grayI);
title('Roate 90 right image');
axis off;

figure('Name', 'Result color images');
% first image
subplot(1, 4, 1);               % set image position
imshow(colorI);                 % plot image
title('Color image');           % set title

% second image
subplot(1, 4, 2);
imshow(R);
title('Red channel');

% third image
subplot(1, 4, 3);
imshow(G);
title('Green channel');

% forth image
subplot(1, 4, 4);
imshow(B);
title('Blue channel');