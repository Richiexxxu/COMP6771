function J = rotate90(I, direction)
    
    if(strcmp(direction, 'left') == 0)
        J = flipV(I)';
    elseif(strcmp(direction, 'right') == 0)
        J = flipV(I');
    end
end